package com.example.presencemanager

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // ربط الزر الموجود في الواجهة الرئيسية
        val btnCommencer = findViewById<Button>(R.id.btnCommernicer)

        // الانتقال إلى لوحة التحكم (DashboardActivity) عند الضغط على الزر
        btnCommencer.setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
        }
    }
}